# S8411-45R.pretty
KiCad Footprint for S8411-45R 12mm coin cell battery holder
